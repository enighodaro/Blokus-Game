
/**
 * Write a description of class Block_Bank here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Block_Bank
{
    // instance variables 
    
    /**
     * A main method that calls GridBoard and Blocks
     */
    public static void main( String args [])
    {
        // put your code here
        new GridBoard();
        new Blocks();
    }
}
